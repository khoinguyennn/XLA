clc; clear; close all;

img_list = {'dataImages/Fig0314(a)(100-dollars).tif', ...
            'dataImages/Fig0312(a)(kidney).tif', ...
            'dataImages/Fig0310(b)(washed_out_pollen_image).tif', ...
            'dataImages/Fig0314(a)(100-dollars).tif'};

K = length(img_list);

% --- ??c ?nh ??u ti�n ?? l?y k�ch th??c chu?n ---
g0 = imread(img_list{1});
if size(g0,3) == 3
    g0 = rgb2gray(g0);
end
[H, W] = size(g0);

sum_img = zeros(H, W);

for i = 1:K
    g = imread(img_list{i});

    % Convert to grayscale n?u l� RGB
    if size(g,3) == 3
        g = rgb2gray(g);
    end

    % Resize ?? ph� h?p k�ch th??c ?nh ??u ti�n
    g = imresize(g, [H W]);

    sum_img = sum_img + double(g);
end

avg_img = uint8(sum_img / K);

figure;
subplot(1,2,1); imshow(uint8(g0)); title('Example Noisy Image');
subplot(1,2,2); imshow(avg_img); title(['Averaged Image from ', num2str(K), ' frames']);
