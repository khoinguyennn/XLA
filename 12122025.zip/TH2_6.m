%2.6. Ph�n t�ch ng??ng
I=imread('dataImages/coins.png'); %V? l??c ?? x�m ?nh I
subplot(1,2,1), imshow(I);
subplot(1,2,2), imhist(I); 

I=imread('dataImages/coins.png');
[counts,bins]=imhist(I); %??m s? m?c x�m 
counts(60) %truy v?n gi� tr? x�m 60