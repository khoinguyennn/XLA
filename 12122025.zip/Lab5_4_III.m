function H = myHistogram(img)
    img = uint8(img);

    H = zeros(1,256);

    for x = 1:size(img,1)
        for y = 1:size(img,2)
            H(img(x,y) + 1) = H(img(x,y) + 1) + 1;
        end
    end
end



function eq_img = myHisteq(img)

img = uint8(img);

H = myHistogram(img);
N = numel(img);

% PDF
pdf = H / N;

% CDF
cdf = zeros(1,256);
cdf(1) = pdf(1);

for k = 2:256
    cdf(k) = cdf(k-1) + pdf(k);
end

% Transformation function
T = uint8(255 * cdf);

% Apply transform
eq_img = zeros(size(img), 'uint8');

for x = 1:size(img,1)
    for y = 1:size(img,2)
        eq_img(x,y) = T(img(x,y) + 1);
    end
end

end
