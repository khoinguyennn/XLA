%1.2 D?a tr�n c�u tr? l?i c?a c�u 1.1, s? d?ng c?u tr�c l?p for ?? l?p l?i ph�p t�nh tr�n ??i v?i t?t c? pixel c?a ?nh I ?? t?o ra hai ?nh I1, I2
% K�ch th??c c?a ?nh
[rows, cols] = size(I);  % ??i v?i ?nh grayscale, s? c� 2 chi?u (row, column)

% T?o ?nh I1 v� I2 v?i k�ch th??c t??ng t? nh? ?nh g?c
I1 = I;  % Sao ch�p ?nh g?c v�o I1
I2 = I;  % Sao ch�p ?nh g?c v�o I2

% D�ng v�ng l?p for ?? thay ??i t?t c? c�c pixel trong ?nh
for i = 1:rows
    for j = 1:cols
        % C?ng 25 v�o gi� tr? c?a pixel t?i (i,j) cho ?nh I1
        I1(i,j) = min(max(I(i,j) + 25, 0), 255);  % ??m b?o gi� tr? kh�ng v??t qu� [0, 255]
        
        % Tr? 25 v�o gi� tr? c?a pixel t?i (i,j) cho ?nh I2
        I2(i,j) = min(max(I(i,j) - 25, 0), 255);  % ??m b?o gi� tr? kh�ng v??t qu� [0, 255]
    end
end

% Hi?n th? c�c ?nh ?� ???c thay ??i
subplot(1,3,1);
imshow(I);
title('?nh g?c');

subplot(1,3,2);
imshow(I1);
title('?nh I1 (C?ng 25 v�o c�c pixel)');
subplot(1,3,3);
imshow(I2);
title('?nh I2 (Tr? 25 v�o c�c pixel)');