I = imread('dataImages/Fig0304(a)(breast_digital_Xray).tif');
I = im2double(I);

% Negative Transform
negI = 1 - I;

figure;
subplot(2,2,1); imshow(I); title('Original Image');
subplot(2,2,2); imhist(I); title('Histogram Original');

subplot(2,2,3); imshow(negI); title('Negative Image');
subplot(2,2,4); imhist(negI); title('Histogram Negative');