%2.9. L?c tuy?n t�nh: t?ng c?a c�c t�ch gi?a h? s? c?a b? l?c v?i c?p x�m c?a ?i?m ?nh t??ng ?ng trong v�ng �p d?ng l?c.
% B??c 1: ??c ?nh
f = imread('dataImages/Fig0333(a)(test_pattern_blurring_orig).tif');  % ??c ?nh

% B??c 2: T?o m?t n? l?c w
w = (1/3) * ones(3, 3);  % M?t n? 3x3 v?i gi� tr? m?i ph?n t? l� 1/3

% B??c 3: �p d?ng l?c v?i h�m imfilter
% Ch?n 'conv' cho Convolution, 'replicate' cho bi�n, 'same' ?? ?nh ??u ra c� k�ch th??c b?ng ?nh g?c
g = imfilter(f, w, 'conv', 'replicate', 'same');

% B??c 4: Hi?n th? ?nh g?c v� ?nh sau khi l?c
figure;
subplot(1, 2, 1);
imshow(f);
title('Anh goc');

subplot(1, 2, 2);
imshow(g);
title('Anh sau khi loc');