% 2.1 Cho m?t ?nh ?a m?c x�m r=�Fig0304(a)(breast_digital_Xray).tif�. 
%Y�u c?u th?c hi?n c�c ph�p x? l� sau:
    %a. Ph�n t�ch s? ph�n b? m?c x�m c?a ?nh
    %b. Vi?t code ?? bi?n ??i �m b?n ?nh tr�n
    %sa=L-1-r. Trong ?� r ?nh ??u v�o, L c?p m?c x�m.
    %c. so s�nh l??c ?? x�m ?nh Sa v� r, gi?i th�ch.
    %d. ch?n ng??ng t=127. Vi?t code ?? t?o ra ?nh nh? ph�n t? ?nh r.
    
r = imread('dataImages/Fig0304(a)(breast_digital_Xray).tif');

figure;
imhist(r);  % V? l??c ?? x�m c?a ?nh
title('Luoc do xam cua anh r');
xlabel('Muc xam');
ylabel('So luong pixel');

% Bi?n ??i ?nh �m b?n
L = 256; %S? c?p m?c x�m (8-bit)
S_a = L - 1 - r; %Bi?n ??i �m b?n ?nh

figure;
imshow(S_a);
title('Anh am ban cua anh r');

% So s�nh l??c ?? x�m c?a ?nh Sa v� r
figure;
subplot(1,2,1);
imhist(r);
title('Luoc do xam cua anh r');

subplot(1,2,2);
imhist(S_a);
title('Luoc do xam cua anh am ban S_a');

%T?o ?nh nh? ph�n t? ?nh r v?i ng??ng t = 127
t= 127;
binary_img = r >= t;
figure;
imshow(binary_img);
title('Anh nhi phan cua anh r voi nguong t = 127');


%2.2 Cho ?nh ?a m?c x�m i=�Fig0122(a)(fractal-iris).tif�. Y�u c?u th?c
%hi?n c�c ph�p x? l� l�m m?ng m?t ph?ng bit:
%a. T?o ?nh i3 t? bit plane th? 3 c?a ?nh I (d�ng h�m bitget)
%b. T?o ?nh i6 t? bit plane th? 6 c?a ?nh i
%c. T?o ?nh i78 t? bit plane th? 7, th? 8 c?a ?nh I (d�ng h�m bitget v� bitset)

% ??c ?nh
i = imread('dataImages/Fig0122(a)(fractal-iris).tif');  % ??c ?nh ?a m?c x�m

% a. T?o ?nh i3 t? bit plane th? 3
i3 = bitget(i, 3);  % L?y bit th? 3 c?a ?nh

% Hi?n th? ?nh i3
figure;
imshow(i3);
title('Anh i3 tu bit plane thu 3');

% b. T?o ?nh i6 t? bit plane th? 6
i6 = bitget(i, 6);  % L?y bit th? 6 c?a ?nh

% Hi?n th? ?nh i6
figure;
imshow(i6);
title('Anh i6 tu bit plane thu 6');

% c. T?o ?nh i78 t? bit plane th? 7 v� 8
i78 = zeros(size(i));  % Kh?i t?o ?nh i78 v?i t?t c? gi� tr? b?ng 0
i78 = bitset(i78, 7, bitget(i, 7));  % L?y bit th? 7 c?a ?nh i v� ??t v�o ?nh i78
i78 = bitset(i78, 8, bitget(i, 8));  % L?y bit th? 8 c?a ?nh i v� ??t v�o ?nh i78

% Hi?n th? ?nh i78
figure;
imshow(i78);
title('Anh i78 tu bit plane thu 7 va 8');

%2.3 C�n b?ng m?c x�m, cho ?nh 256 c?p x�m i= �Fig0316(4)(bottom_left).tif�:
%a. Xem ?nh, ph�n t�ch l??c ?? x�m ?nh i.
%b. C�n l??c ?? x�m ?nh I, d�ng h�m histeq(i,gray-scale level)
%c. xem ?nh v?a ???c c�n b?ng m?c x�m v� l??c ?? x�m c?a ?nh.

% B??c 1: ??c ?nh
i = imread('dataImages/Fig0316(4)(bottom_left).tif');  % ??c ?nh g?c

% B??c 2: Hi?n th? ?nh v� ph�n t�ch l??c ?? x�m c?a ?nh g?c
figure;
imshow(i);
title('Anh goc');

figure;
imhist(i);  % V? l??c ?? x�m c?a ?nh
title('Luoc do xam cua anh goc');
xlabel('Muc xam');
ylabel('So luong pixel');

% B??c 3: C�n b?ng l??c ?? x�m c?a ?nh
i_eq = histeq(i, 256);  % C�n b?ng m?c x�m c?a ?nh, s? c?p x�m = 256

% B??c 4: Hi?n th? ?nh ?� c�n b?ng m?c x�m v� l??c ?? x�m c?a ?nh ?� c�n b?ng
figure;
imshow(i_eq);
title('Anh sau khi can bang muc xam');

figure;
imhist(i_eq);  % V? l??c ?? x�m c?a ?nh ?� c�n b?ng m?c x�m
title('Luoc do xam cua anh sau khi can bang muc xam');
xlabel('Muc xam');
ylabel('So luong pixel');


%2.4 C�c ph�p to�n s? h?c tr�n ?nh
%2.4.1.
A=imread('dataImages/cameraman.tif'); %??c ?nh n?p v�o bi?n A
subplot(1,2,1), imshow(A); %hi?n th? ?nh A
B=imadd(A, 100); %c?ng 100 v�o m?i gi� tr? pixel c?a A
subplot(1,2,2), imshow(B); % hi?n th? ?nh B

%2.4.2.

A=imread('dataImages/cola1.png'); %??c ?nh th? nh?t
B=imread('dataImages/cola2.png'); % ??c ?nh th? hai
subplot(1,3,1), imshow(A); %hi?n th? ?nh th? nh?t
subplot(1,3,2), imshow(B); %hi?n th? ?nh th? hai
Output = imsubtract(A, B); %imsubtract(A,B) ~ A-B
subplot(1,3,3),imshow(Output); %hi?n th? ?nh k?t qu?
Output1 = imabsdiff(A, B); %tr? ?nh
subplot(1,3,3),imshow(Output1); %hi?n th? ?nh k?t qu? 1

%2.4.3.

Output = immultiply(A,1.5); %nh�n ?nh v?i 1.5
subplot(1,3,3), imshow(Output); %hi?n th? ?nh k?t qu?
Output = imdivide(A,4); %chia gia tr? pixel v?i 4
subplot(1,3,3), imshow(Output); %hi?n th? ?nh k?t qu?

%2.4.4.
A=imread('dataImages/toycars1.png'); %Read in 1st image
B=imread('dataImages/toycars2.png'); %Read in 2nd image
Abw=im2bw(A); %convert to binary
Bbw=im2bw(B); %convert to binary
subplot(1,3,1), imshow(Abw); %Display 1st image
subplot(1,3,2), imshow(Bbw); %Display 2nd image
Output = xor(Abw, Bbw); %xor images images
subplot(1,3,3), imshow(Output); %Display result

%2.4.5.
I=imread('dataImages/trees.tif'); %Read in 1st image
T=im2bw(I, 0.1); %Perform thresholding, ng??ng 0->1
subplot(1,3,1), imshow(I); %Display original image
subplot(1,3,2), imshow(T); %Display thresholded image

%2.5. Bi?n ??i logarit
I=imread('dataImages/cameraman.tif');  %bi?n ??i logarit
subplot(2,2,1), imshow(I);
Id=im2double(I);
Output1=2*log(1+Id);
Output2=3*log(1+Id);
Output3=5*log(1+Id);
subplot(2,2,2),imshow(Output1);
subplot(2,2,3),imshow(Output2);
subplot(2,2,4),imshow(Output3);

%2.6. Ph�n t�ch ng??ng
I=imread('dataImages/coins.png'); %V? l??c ?? x�m ?nh I
subplot(1,2,1), imshow(I);
subplot(1,2,2), imhist(I); 

I=imread('dataImages/coins.png');
[counts,bins]=imhist(I); %??m s? m?c x�m 
counts(60) %truy v?n gi� tr? x�m 60

%2.7. S? d?ng k? thu?t ch?n ng??ng ? ?o?n code 5* v� v� d? ? c�u 2.6. x�c ??nh v� �p ng??ng ??i v?i ?nh pillsetc.png. T??ng t? cho nh?ng ?nh �tape.png�, �coins.png� v� �eight.tif�.

% B??c 1: ??c ?nh
pillsetc = imread('dataImages/pillsetc.png');
tape = imread('dataImages/tape.png');
coins = imread('dataImages/coins.png');
eight = imread('dataImages/eight.tif');

% B??c 2: X�c ??nh ng??ng cho m?i ?nh (s? d?ng gi� tr? trung b�nh)
threshold_pillsetc = mean(pillsetc(:));  % Gi� tr? trung b�nh c?a ?nh pillsetc
threshold_tape = mean(tape(:));  % Gi� tr? trung b�nh c?a ?nh tape
threshold_coins = mean(coins(:));  % Gi� tr? trung b�nh c?a ?nh coins
threshold_eight = mean(eight(:));  % Gi� tr? trung b�nh c?a ?nh eight

% B??c 3: T?o ?nh nh? ph�n b?ng c�ch �p d?ng ng??ng
binary_pillsetc = pillsetc >= threshold_pillsetc;
binary_tape = tape >= threshold_tape;
binary_coins = coins >= threshold_coins;
binary_eight = eight >= threshold_eight;

% B??c 4: Hi?n th? ?nh nh? ph�n
figure;
subplot(2,2,1);
imshow(binary_pillsetc);
title('Anh nhi phan - pillsetc.png');

subplot(2,2,2);
imshow(binary_tape);
title('Anh nhi phan - tape.png');

subplot(2,2,3);
imshow(binary_coins);
title('Anh nhi phan - coins.png');

subplot(2,2,4);
imshow(binary_eight);
title('Anh nhi phan - eight.tif');

%2.8 Ph�p tr? ?nh g(x,y)=f(x,y)-h(x,y)
    %a. cho ?nh f=�Fig0122(a)(fractal-iris).tif�,so?n code file .m t?o ?nh h b?ng c�ch ??t 4 plane bit th?p c?a ?nh f b?ng 0.
    %b. T?o ?nh g t? vi?c tr? hai ?nh f v� h cho nhau theo t?ng pixel t??ng ?ng.
    %c. T?o ?nh i t? vi?c c�n b?ng m?c x�m c?a ?nh g.
    
% B??c 1: ??c ?nh f
f = imread('dataImages/Fig0122(a)(fractal-iris).tif');  % ??c ?nh f

% B??c 2: T?o ?nh h b?ng c�ch ??t 4 bit plane th?p nh?t c?a ?nh f b?ng 0
h = f;  % Sao ch�p ?nh f v�o ?nh h

% ??t 4 bit th?p nh?t (bit 1 ??n bit 4) c?a ?nh h b?ng 0
for row = 1:size(f,1)
    for col = 1:size(f,2)
        pixel_value = f(row, col);
        % ??t 4 bit th?p nh?t c?a pixel b?ng 0
        pixel_value = bitshift(pixel_value, -4);  % D?ch 4 bit sang ph?i
        pixel_value = bitshift(pixel_value, 4);  % D?ch ng??c l?i 4 bit ?? gi? c�c bit cao
        h(row, col) = pixel_value;  % G�n gi� tr? m?i cho ?nh h
    end
end

% B??c 3: T?o ?nh g t? vi?c tr? ?nh f v� h
g = f - h;

% B??c 4: T?o ?nh i t? vi?c c�n b?ng m?c x�m c?a ?nh g
i = histeq(g);  % C�n b?ng m?c x�m c?a ?nh g

% Hi?n th? k?t qu?

% Hi?n th? ?nh f
figure;
imshow(f);
title('Anh f');

% Hi?n th? ?nh h
figure;
imshow(h);
title('Anh h (4 bit thap nhat cua f bi xoa)');

% Hi?n th? ?nh g
figure;
imshow(g);
title('Anh g (f - h)');

% Hi?n th? ?nh i (c�n b?ng m?c x�m c?a g)
figure;
imshow(i);
title('Anh i (can bang muc xam cua g)');

%2.9. L?c tuy?n t�nh: t?ng c?a c�c t�ch gi?a h? s? c?a b? l?c v?i c?p x�m c?a ?i?m ?nh t??ng ?ng trong v�ng �p d?ng l?c.
% B??c 1: ??c ?nh
f = imread('dataImages/Fig0333(a)(test_pattern_blurring_orig).tif');  % ??c ?nh

% B??c 2: T?o m?t n? l?c w
w = (1/3) * ones(3, 3);  % M?t n? 3x3 v?i gi� tr? m?i ph?n t? l� 1/3

% B??c 3: �p d?ng l?c v?i h�m imfilter
% Ch?n 'conv' cho Convolution, 'replicate' cho bi�n, 'same' ?? ?nh ??u ra c� k�ch th??c b?ng ?nh g?c
g = imfilter(f, w, 'conv', 'replicate', 'same');

% B??c 4: Hi?n th? ?nh g?c v� ?nh sau khi l?c
figure;
subplot(1, 2, 1);
imshow(f);
title('?nh g?c');

subplot(1, 2, 2);
imshow(g);
title('?nh sau khi l?c');

%2.10. L?c phi tuy?n � l?c trung v?
% B??c 1: N?p ?nh
i = imread('dataImages/coins.png');  % ??c ?nh g?c

% B??c 2: G�y nhi?u mu?i - ti�u v?i t? l? 3%
i_saltpepper = imnoise(i, 'salt & pepper', 0.03);  % Th�m nhi?u mu?i - ti�u

% Hi?n th? ?nh v?i nhi?u mu?i - ti�u
figure;
imshow(i_saltpepper);
title('?nh v?i nhi?u mu?i - ti�u (3%)');

% B??c 3: L?c ?nh b?ng h�m medfilt2 (L?c trung v?)
i_filtered = medfilt2(i_saltpepper, [3 3], 'symmetric');  % L?c trung v? v?i c?a s? 3x3

% Hi?n th? ?nh sau khi l?c
figure;
imshow(i_filtered);
title('?nh sau khi l?c trung v?');

% B??c 4: G�y nhi?u Gaussian v?i t? l? 2%
i_gaussian = imnoise(i, 'gaussian', 0, 0.02);  % Th�m nhi?u Gaussian v?i ph??ng sai 0.02

% Hi?n th? ?nh v?i nhi?u Gaussian
figure;
imshow(i_gaussian);
title('?nh v?i nhi?u Gaussian (2%)');

% B??c 5: L?c ?nh nhi?u Gaussian b?ng medfilt2
i_gaussian_filtered = medfilt2(i_gaussian, [3 3], 'symmetric');  % L?c trung v? v?i c?a s? 3x3

% Hi?n th? ?nh sau khi l?c nhi?u Gaussian
figure;
imshow(i_gaussian_filtered);
title('?nh sau khi l?c nhi?u Gaussian');

% 2.11 �p d?ng b? l?c sau v?i �Fig0335(a)(ckt_board_saltpep_prob_pt05).tif�:
    %a. L?c tuy?n t�nh.
    %b. L?c phi tuy?n ? so s�nh 2 ph??ng ph�p l?c, nh?n x�t
    

% B??c 1: ??c ?nh
f = imread('dataImages/Fig0335(a)(ckt_board_saltpep_prob_pt05).tif');  % ??c ?nh g?c

% B??c 2: L?c tuy?n t�nh (B? l?c trung b�nh)
h = fspecial('average', [3 3]);  % M?t n? l?c trung b�nh 3x3
g_linear = imfilter(f, h, 'conv', 'symmetric');  % �p d?ng b? l?c tuy?n t�nh

% B??c 3: L?c phi tuy?n (B? l?c trung v?)
g_median = medfilt2(f, [3 3], 'symmetric');  % �p d?ng b? l?c phi tuy?n (l?c trung v?)

% B??c 4: Hi?n th? ?nh g?c v� ?nh ?� l?c

% Hi?n th? ?nh g?c
figure;
subplot(2, 2, 1);
imshow(f);
title('?nh g?c');

% Hi?n th? ?nh sau khi l?c tuy?n t�nh
subplot(2, 2, 2);
imshow(g_linear);
title('?nh sau khi l?c tuy?n t�nh');

% Hi?n th? ?nh sau khi l?c phi tuy?n
subplot(2, 2, 3);
imshow(g_median);
title('?nh sau khi l?c phi tuy?n');

% So s�nh ?nh
subplot(2, 2, 4);
imshow(abs(double(g_linear) - double(g_median)), []);
title('So s�nh s? kh�c bi?t');


%Nh?n x�t v� so s�nh:
    %L?c tuy?n t�nh (B? l?c trung b�nh):
    %?u ?i?m: D? th?c hi?n v� t�nh to�n ??n gi?n. Th??ng ???c s? d?ng ?? l�m m??t ?nh.
    %Nh??c ?i?m: Kh�ng hi?u qu? trong vi?c lo?i b? nhi?u "mu?i - ti�u", v� m?i pixel trong ?nh b? thay th? b?ng trung b�nh c?a c�c pixel xung quanh, c� th? l�m m? c�c chi ti?t quan tr?ng trong ?nh.
    %L?c phi tuy?n (B? l?c trung v?):
    %?u ?i?m: Hi?u qu? trong vi?c lo?i b? nhi?u "mu?i - ti�u" m� kh�ng l�m m? chi ti?t ?nh. Ph� h?p v?i ?nh b? nhi?u mu?i - ti�u.
    %Nh??c ?i?m: L?c phi tuy?n kh�ng ph?i l�c n�o c?ng gi? ???c t?t c? c�c chi ti?t trong ?nh, v� ?�i khi c� th? g�y m?t m?t s? chi ti?t nh?.




