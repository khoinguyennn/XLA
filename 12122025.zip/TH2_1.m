% 2.1 Cho m?t ?nh ?a m?c x�m r=�Fig0304(a)(breast_digital_Xray).tif�. 
%Y�u c?u th?c hi?n c�c ph�p x? l� sau:
    %a. Ph�n t�ch s? ph�n b? m?c x�m c?a ?nh
    %b. Vi?t code ?? bi?n ??i �m b?n ?nh tr�n
    %sa=L-1-r. Trong ?� r ?nh ??u v�o, L c?p m?c x�m.
    %c. so s�nh l??c ?? x�m ?nh Sa v� r, gi?i th�ch.
    %d. ch?n ng??ng t=127. Vi?t code ?? t?o ra ?nh nh? ph�n t? ?nh r.
    
r = imread('dataImages/Fig0304(a)(breast_digital_Xray).tif');

figure;
imhist(r);  % V? l??c ?? x�m c?a ?nh
title('Luoc do xam cua anh r');
xlabel('Muc xam');
ylabel('So luong pixel');

% Bi?n ??i ?nh �m b?n
L = 256; %S? c?p m?c x�m (8-bit)
S_a = L - 1 - r; %Bi?n ??i �m b?n ?nh

figure;
imshow(S_a);
title('Anh am ban cua anh r');

% So s�nh l??c ?? x�m c?a ?nh Sa v� r
figure;
subplot(1,2,1);
imhist(r);
title('Luoc do xam cua anh r');

subplot(1,2,2);
imhist(S_a);
title('Luoc do xam cua anh am ban S_a');

%T?o ?nh nh? ph�n t? ?nh r v?i ng??ng t = 127
t= 127;
binary_img = r >= t;
figure;
imshow(binary_img);
title('Anh nhi phan cua anh r voi nguong t = 127');