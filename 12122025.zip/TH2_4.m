%2.4 C�c ph�p to�n s? h?c tr�n ?nh
%2.4.1.
A=imread('dataImages/cameraman.tif'); %??c ?nh n?p v�o bi?n A
subplot(1,2,1), imshow(A); %hi?n th? ?nh A
B=imadd(A, 100); %c?ng 100 v�o m?i gi� tr? pixel c?a A
subplot(1,2,2), imshow(B); % hi?n th? ?nh B

%2.4.2.

A=imread('dataImages/cola1.png'); %??c ?nh th? nh?t
B=imread('dataImages/cola2.png'); % ??c ?nh th? hai
subplot(1,3,1), imshow(A); %hi?n th? ?nh th? nh?t
subplot(1,3,2), imshow(B); %hi?n th? ?nh th? hai
Output = imsubtract(A, B); %imsubtract(A,B) ~ A-B
subplot(1,3,3),imshow(Output); %hi?n th? ?nh k?t qu?
Output1 = imabsdiff(A, B); %tr? ?nh
subplot(1,3,3),imshow(Output1); %hi?n th? ?nh k?t qu? 1

%2.4.3.

Output = immultiply(A,1.5); %nh�n ?nh v?i 1.5
subplot(1,3,3), imshow(Output); %hi?n th? ?nh k?t qu?
Output = imdivide(A,4); %chia gia tr? pixel v?i 4
subplot(1,3,3), imshow(Output); %hi?n th? ?nh k?t qu?

%2.4.4.
A=imread('dataImages/toycars1.png'); %Read in 1st image
B=imread('dataImages/toycars2.png'); %Read in 2nd image
Abw=im2bw(A); %convert to binary
Bbw=im2bw(B); %convert to binary
subplot(1,3,1), imshow(Abw); %Display 1st image
subplot(1,3,2), imshow(Bbw); %Display 2nd image
Output = xor(Abw, Bbw); %xor images images
subplot(1,3,3), imshow(Output); %Display result

%2.4.5.
I=imread('dataImages/trees.tif'); %Read in 1st image
T=im2bw(I, 0.1); %Perform thresholding, ng??ng 0->1
subplot(1,3,1), imshow(I); %Display original image
subplot(1,3,2), imshow(T); %Display thresholded image