%2.10. L?c phi tuy?n � l?c trung v?
% B??c 1: N?p ?nh
i = imread('dataImages/coins.png');  % ??c ?nh g?c

% B??c 2: G�y nhi?u mu?i - ti�u v?i t? l? 3%
i_saltpepper = imnoise(i, 'salt & pepper', 0.03);  % Th�m nhi?u mu?i - ti�u

% Hi?n th? ?nh v?i nhi?u mu?i - ti�u
figure;
imshow(i_saltpepper);
title('Anh voi nhieu muoi - tieu (3%)');

% B??c 3: L?c ?nh b?ng h�m medfilt2 (L?c trung v?)
i_filtered = medfilt2(i_saltpepper, [3 3], 'symmetric');  % L?c trung v? v?i c?a s? 3x3

% Hi?n th? ?nh sau khi l?c
figure;
imshow(i_filtered);
title('Anh sau khi loc trung vi');

% B??c 4: G�y nhi?u Gaussian v?i t? l? 2%
i_gaussian = imnoise(i, 'gaussian', 0, 0.02);  % Th�m nhi?u Gaussian v?i ph??ng sai 0.02

% Hi?n th? ?nh v?i nhi?u Gaussian
figure;
imshow(i_gaussian);
title('Anh voi nhieu Gaussian (2%)');

% B??c 5: L?c ?nh nhi?u Gaussian b?ng medfilt2
i_gaussian_filtered = medfilt2(i_gaussian, [3 3], 'symmetric');  % L?c trung v? v?i c?a s? 3x3

% Hi?n th? ?nh sau khi l?c nhi?u Gaussian
figure;
imshow(i_gaussian_filtered);
title('Anh sau khi loc nhieu Gaussian');