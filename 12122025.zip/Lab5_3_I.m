clc; clear; close all;

img_list = { ...
    'dataImages/Fig0310(b)(washed_out_pollen_image).tif', ...
    'dataImages/cameraman.tif', ...
    'dataImages/Fig0122(a)(fractal-iris).tif', ...
    'dataImages/Fig0323(a)(mars_moon_phobos).tif', ...
    'dataImages/Fig0314(a)(100-dollars).tif', ...
    'dataImages/Fig0312(a)(kidney).tif', ...
    'dataImages/Fig0343(a)(skeleton_orig).tif' ...
    };

for k = 1:length(img_list)
    [img, map] = imread(img_list{k});

    % --- CASE 1: indexed image ---
    if ~isempty(map)
        gray = ind2gray(img, map);

    % --- CASE 2: RGB image ---
    elseif ndims(img) == 3
        gray = rgb2gray(img);

    % --- CASE 3: grayscale already ---
    else
        gray = img;
    end

    eq = histeq(gray);

    figure;
    subplot(1,2,1); imshow(gray); title(['Original: ', img_list{k}]);
    subplot(1,2,2); imshow(eq); title('Histogram Equalization');
end
