% 3.2 Ph�t hi?n bi�n
% B??c 1: X�y d?ng c�c m?t n? ph�t hi?n bi�n
w_ngang = [-1 -1 -1; 2 2 2; -1 -1 -1];  % M?t n? ph�t hi?n bi�n ngang
w_45 = [-1 -1 2; -1 2 2; -1 -1 2];      % M?t n? ph�t hi?n bi�n 45�
w_doc = [2 -1 -1; 2 2 -1; -1 -1 -1];    % M?t n? ph�t hi?n bi�n d?c

% B??c 2: ??c ?nh
f = imread('dataImages/Fig1005(a)(wirebond_mask).tif');  % ??c ?nh

% B??c 3: �p d?ng c�c m?t n? ph�t hi?n bi�n l�n ?nh
g_ngang = imfilter(f, w_ngang, 'conv', 'symmetric');  % L?c v?i m?t n? ngang
g_45 = imfilter(f, w_45, 'conv', 'symmetric');       % L?c v?i m?t n? 45�
g_doc = imfilter(f, w_doc, 'conv', 'symmetric');     % L?c v?i m?t n? d?c

% B??c 4: Hi?n th? ?nh g?c v� ?nh sau khi l?c
figure;
subplot(2, 2, 1);
imshow(f);
title('Anh goc');

subplot(2, 2, 2);
imshow(g_ngang);
title('Anh sau khi ph�t hien bien ngang');

subplot(2, 2, 3);
imshow(g_45);
title('Anh sau khi phat hien bien 45�');

subplot(2, 2, 4);
imshow(g_doc);
title('Anh sau khi phat hien bien doc');