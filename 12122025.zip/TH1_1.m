%1.1 D�ng MATLAB ??c, hi?n th? ?nh c�ng v?i truy xu?t v? tr� c?a pixel.
I = imread('dataImages/cell.tif');
imshow(I);

% Truy xu?t v� thay ??i gi� tr? pixel t?i (100, 20)
original_pixel_value = I(100, 20);
disp(['Gi� tr? pixel ban ??u t?i (100, 20): ', num2str(original_pixel_value)]);


% C?ng 25 v�o gi� tr? pixel
I(100, 20) = I(100, 20) + 25;
imshow(I);
title('?nh sau khi c?ng 25 v�o pixel (100, 20)');
% Tr? 25 v�o gi� tr? pixel
I(100, 20) = I(100, 20) - 25;
imshow(I);
title('?nh sau khi tr? 25 v�o pixel (100, 20)');