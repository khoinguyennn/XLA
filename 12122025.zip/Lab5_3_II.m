clc; clear; close all;

img = imread('dataImages/Fig0314(a)(100-dollars).tif');
gray = double(img);

% lo?i b? 3 bit th?p nh?t (v� d?)
discarded = bitand(uint8(gray), uint8(248));  % gi? 5 bit cao

difference = double(img) - double(discarded);

% stretch contrast (equalize)
diff_eq = histeq(uint8(difference));

figure;
subplot(2,2,1); imshow(uint8(img)); title('Original Image');
subplot(2,2,2); imshow(uint8(discarded)); title('Discarded Bit Image');
subplot(2,2,3); imshow(uint8(difference)); title('Difference Image');
subplot(2,2,4); imshow(diff_eq); title('Enhanced (Equalized)');