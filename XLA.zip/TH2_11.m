% 2.11 �p d?ng b? l?c sau v?i �Fig0335(a)(ckt_board_saltpep_prob_pt05).tif�:
    %a. L?c tuy?n t�nh.
    %b. L?c phi tuy?n ? so s�nh 2 ph??ng ph�p l?c, nh?n x�t
    

% B??c 1: ??c ?nh
f = imread('dataImages/Fig0335(a)(ckt_board_saltpep_prob_pt05).tif');  % ??c ?nh g?c

% B??c 2: L?c tuy?n t�nh (B? l?c trung b�nh)
h = fspecial('average', [3 3]);  % M?t n? l?c trung b�nh 3x3
g_linear = imfilter(f, h, 'conv', 'symmetric');  % �p d?ng b? l?c tuy?n t�nh

% B??c 3: L?c phi tuy?n (B? l?c trung v?)
g_median = medfilt2(f, [3 3], 'symmetric');  % �p d?ng b? l?c phi tuy?n (l?c trung v?)

% B??c 4: Hi?n th? ?nh g?c v� ?nh ?� l?c

% Hi?n th? ?nh g?c
figure;
subplot(2, 2, 1);
imshow(f);
title('Anh goc');

% Hi?n th? ?nh sau khi l?c tuy?n t�nh
subplot(2, 2, 2);
imshow(g_linear);
title('Anh sau khi loc tuyen t�nh');

% Hi?n th? ?nh sau khi l?c phi tuy?n
subplot(2, 2, 3);
imshow(g_median);
title('Anh sau khi loc phi tuyen');

% So s�nh ?nh
subplot(2, 2, 4);
imshow(abs(double(g_linear) - double(g_median)), []);
title('So sanh su khac biet');


%Nh?n x�t v� so s�nh:
    %L?c tuy?n t�nh (B? l?c trung b�nh):
    %?u ?i?m: D? th?c hi?n v� t�nh to�n ??n gi?n. Th??ng ???c s? d?ng ?? l�m m??t ?nh.
    %Nh??c ?i?m: Kh�ng hi?u qu? trong vi?c lo?i b? nhi?u "mu?i - ti�u", v� m?i pixel trong ?nh b? thay th? b?ng trung b�nh c?a c�c pixel xung quanh, c� th? l�m m? c�c chi ti?t quan tr?ng trong ?nh.
    %L?c phi tuy?n (B? l?c trung v?):
    %?u ?i?m: Hi?u qu? trong vi?c lo?i b? nhi?u "mu?i - ti�u" m� kh�ng l�m m? chi ti?t ?nh. Ph� h?p v?i ?nh b? nhi?u mu?i - ti�u.
    %Nh??c ?i?m: L?c phi tuy?n kh�ng ph?i l�c n�o c?ng gi? ???c t?t c? c�c
    %chi ti?t trong ?nh, v� ?�i khi c� th? g�y m?t m?t s? chi ti?t nh?.S