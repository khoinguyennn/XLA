%1.1 D�ng MATLAB ??c, hi?n th? ?nh c�ng v?i truy xu?t v? tr� c?a pixel.
I = imread('dataImages/cell.tif');
imshow(I);

% Truy xu?t v� thay ??i gi� tr? pixel t?i (100, 20)
original_pixel_value = I(100, 20);
disp(['Gi� tr? pixel ban ??u t?i (100, 20): ', num2str(original_pixel_value)]);


% C?ng 25 v�o gi� tr? pixel
I(100, 20) = I(100, 20) + 25;
imshow(I);
title('?nh sau khi c?ng 25 v�o pixel (100, 20)');
% Tr? 25 v�o gi� tr? pixel
I(100, 20) = I(100, 20) - 25;
imshow(I);
title('?nh sau khi tr? 25 v�o pixel (100, 20)');



%1.2 D?a tr�n c�u tr? l?i c?a c�u 1.1, s? d?ng c?u tr�c l?p for ?? l?p l?i ph�p t�nh tr�n ??i v?i t?t c? pixel c?a ?nh I ?? t?o ra hai ?nh I1, I2
% K�ch th??c c?a ?nh
[rows, cols] = size(I);  % ??i v?i ?nh grayscale, s? c� 2 chi?u (row, column)

% T?o ?nh I1 v� I2 v?i k�ch th??c t??ng t? nh? ?nh g?c
I1 = I;  % Sao ch�p ?nh g?c v�o I1
I2 = I;  % Sao ch�p ?nh g?c v�o I2

% D�ng v�ng l?p for ?? thay ??i t?t c? c�c pixel trong ?nh
for i = 1:rows
    for j = 1:cols
        % C?ng 25 v�o gi� tr? c?a pixel t?i (i,j) cho ?nh I1
        I1(i,j) = min(max(I(i,j) + 25, 0), 255);  % ??m b?o gi� tr? kh�ng v??t qu� [0, 255]
        
        % Tr? 25 v�o gi� tr? c?a pixel t?i (i,j) cho ?nh I2
        I2(i,j) = min(max(I(i,j) - 25, 0), 255);  % ??m b?o gi� tr? kh�ng v??t qu� [0, 255]
    end
end

% Hi?n th? c�c ?nh ?� ???c thay ??i
subplot(1,3,1);
imshow(I);
title('?nh g?c');

subplot(1,3,2);
imshow(I1);
title('?nh I1 (C?ng 25 v�o c�c pixel)');
subplot(1,3,3);
imshow(I2);
title('?nh I2 (Tr? 25 v�o c�c pixel)');

%1.3. ??c ?nh �cameraman.tif� v� d�ng h�m imwrite ?? ghi l?i m?t ?nh c� ??nh dang JPEG (ch?ng h?n: Ijpg.jpg) v� m?t ?nh c� ??nh d?ng PNG (ch?ng h?n: Ipng.png). Sau ?� ??c hai ?nh Ijpg.jpg v� Ipng.png v�o hai bi?n t??ng ?ng Ijpg v� Ipng.
%??c l?i ?nh g?c
I = imread('dataImages/cameraman.tif');

%Ghi ?nh th�nh ??nh d?ng JPEG v� PNG
imwrite(I, 'Ijpg.jpg','jpg');
imwrite(I, 'Ipng.png', 'png');

%??c l?i ?nh JPEG v� PNG
Ijpg = imread('Ijpg.jpg');
Ipng = imread('Ipng.png');

%T�nh s? kh�c bi?t tuy?t ??i gi?a hai ?nh

X = imabsdiff(Ijpg, Ipng);

%Hi?n th? s? kh�c bi?t
imagesc(X);
colormap gray;
title('S? kh�c bi?t gi?a ?nh JPEG v� PNG');



