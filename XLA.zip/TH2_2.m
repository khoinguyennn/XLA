%2.2 Cho ?nh ?a m?c x�m i=�Fig0122(a)(fractal-iris).tif�. Y�u c?u th?c
%hi?n c�c ph�p x? l� l�m m?ng m?t ph?ng bit:
%a. T?o ?nh i3 t? bit plane th? 3 c?a ?nh I (d�ng h�m bitget)
%b. T?o ?nh i6 t? bit plane th? 6 c?a ?nh i
%c. T?o ?nh i78 t? bit plane th? 7, th? 8 c?a ?nh I (d�ng h�m bitget v� bitset)

% ??c ?nh
i = imread('dataImages/Fig0122(a)(fractal-iris).tif');  % ??c ?nh ?a m?c x�m

% a. T?o ?nh i3 t? bit plane th? 3
i3 = bitget(i, 3);  % L?y bit th? 3 c?a ?nh

% Hi?n th? ?nh i3
figure;
imshow(i3);
title('Anh i3 tu bit plane thu 3');

% b. T?o ?nh i6 t? bit plane th? 6
i6 = bitget(i, 6);  % L?y bit th? 6 c?a ?nh

% Hi?n th? ?nh i6
figure;
imshow(i6);
title('Anh i6 tu bit plane thu 6');

% c. T?o ?nh i78 t? bit plane th? 7 v� 8
i78 = zeros(size(i));  % Kh?i t?o ?nh i78 v?i t?t c? gi� tr? b?ng 0
i78 = bitset(i78, 7, bitget(i, 7));  % L?y bit th? 7 c?a ?nh i v� ??t v�o ?nh i78
i78 = bitset(i78, 8, bitget(i, 8));  % L?y bit th? 8 c?a ?nh i v� ??t v�o ?nh i78

% Hi?n th? ?nh i78
figure;
imshow(i78);
title('Anh i78 tu bit plane thu 7 va 8');
