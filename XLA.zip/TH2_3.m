%2.3 C�n b?ng m?c x�m, cho ?nh 256 c?p x�m i= �Fig0316(4)(bottom_left).tif�:
%a. Xem ?nh, ph�n t�ch l??c ?? x�m ?nh i.
%b. C�n l??c ?? x�m ?nh I, d�ng h�m histeq(i,gray-scale level)
%c. xem ?nh v?a ???c c�n b?ng m?c x�m v� l??c ?? x�m c?a ?nh.

% B??c 1: ??c ?nh
i = imread('dataImages/Fig0316(4)(bottom_left).tif');  % ??c ?nh g?c

% B??c 2: Hi?n th? ?nh v� ph�n t�ch l??c ?? x�m c?a ?nh g?c
figure;
imshow(i);
title('Anh goc');

figure;
imhist(i);  % V? l??c ?? x�m c?a ?nh
title('Luoc do xam cua anh goc');
xlabel('Muc xam');
ylabel('So luong pixel');

% B??c 3: C�n b?ng l??c ?? x�m c?a ?nh
i_eq = histeq(i, 256);  % C�n b?ng m?c x�m c?a ?nh, s? c?p x�m = 256

% B??c 4: Hi?n th? ?nh ?� c�n b?ng m?c x�m v� l??c ?? x�m c?a ?nh ?� c�n b?ng
figure;
imshow(i_eq);
title('Anh sau khi can bang muc xam');

figure;
imhist(i_eq);  % V? l??c ?? x�m c?a ?nh ?� c�n b?ng m?c x�m
title('Luoc do xam cua anh sau khi can bang muc xam');
xlabel('Muc xam');
ylabel('So luong pixel');