I = imread('dataImages/Fig0304(a)(breast_digital_Xray).tif');
I = im2double(I);

% Image Negative
negativeI = 1 - I;

figure;
subplot(1,2,1); imshow(I); title('Original Image');
subplot(1,2,2); imshow(negativeI); title('Image Negative');