%2.8 Ph�p tr? ?nh g(x,y)=f(x,y)-h(x,y)
    %a. cho ?nh f=�Fig0122(a)(fractal-iris).tif�,so?n code file .m t?o ?nh h b?ng c�ch ??t 4 plane bit th?p c?a ?nh f b?ng 0.
    %b. T?o ?nh g t? vi?c tr? hai ?nh f v� h cho nhau theo t?ng pixel t??ng ?ng.
    %c. T?o ?nh i t? vi?c c�n b?ng m?c x�m c?a ?nh g.
    
% B??c 1: ??c ?nh f
f = imread('dataImages/Fig0122(a)(fractal-iris).tif');  % ??c ?nh f

% B??c 2: T?o ?nh h b?ng c�ch ??t 4 bit plane th?p nh?t c?a ?nh f b?ng 0
h = f;  % Sao ch�p ?nh f v�o ?nh h

% ??t 4 bit th?p nh?t (bit 1 ??n bit 4) c?a ?nh h b?ng 0
for row = 1:size(f,1)
    for col = 1:size(f,2)
        pixel_value = f(row, col);
        % ??t 4 bit th?p nh?t c?a pixel b?ng 0
        pixel_value = bitshift(pixel_value, -4);  % D?ch 4 bit sang ph?i
        pixel_value = bitshift(pixel_value, 4);  % D?ch ng??c l?i 4 bit ?? gi? c�c bit cao
        h(row, col) = pixel_value;  % G�n gi� tr? m?i cho ?nh h
    end
end

% B??c 3: T?o ?nh g t? vi?c tr? ?nh f v� h
g = f - h;

% B??c 4: T?o ?nh i t? vi?c c�n b?ng m?c x�m c?a ?nh g
i = histeq(g);  % C�n b?ng m?c x�m c?a ?nh g

% Hi?n th? k?t qu?

% Hi?n th? ?nh f
figure;
imshow(f);
title('Anh f');

% Hi?n th? ?nh h
figure;
imshow(h);
title('Anh h (4 bit thap nhat cua f bi xoa)');

% Hi?n th? ?nh g
figure;
imshow(g);
title('Anh g (f - h)');

% Hi?n th? ?nh i (c�n b?ng m?c x�m c?a g)
figure;
imshow(i);
title('Anh i (can bang muc xam cua g)');