close all
clear all
% Reading the image and converting it to a gray-level image.
I=imread('dataImages/Fig2_19_a.jpg');

% Reducing the Size of I using nearest neighbor interpolation
I128=imresize(I,0.5); imshow(I128),pause
I64=imresize(I,0.25);close,imshow(I64),pause
I32=imresize(I,0.125);close,imshow(I32),pause
I16=imresize(I,0.0625);close,imshow(I16),pause
% Resizing the Reduced Images to the Original Size (256 X 256) and Comapre
% them:
I16=imresize(I16,16);
I32=imresize(I32,8);
I64=imresize(I64,4);
I128=imresize(I128,2);
figure,subplot(121),subimage(I),title('I'),subplot(122),subimage(I128),tit
le('I128'),pause,close
figure,subplot(221),subimage(I),title('I'),subplot(222),subimage(I64),titl
e('I64'),
subplot(223),subimage(I32),title('I32'),subplot(224),subimage(I16),title('I16'),pause
close all
% Reducing the Size of I using bilinear interpolation
I128_b=imresize(I,0.5,'bilinear');I128_b=imresize(I128_b,2,'bilinear');
I64_b=imresize(I,0.25,'bilinear');I64_b=imresize(I64_b,4,'bilinear');
I32_b=imresize(I,0.125,'bilinear');I32_b=imresize(I32_b,8,'bilinear');
I16_b=imresize(I,0.0625,'bilinear');I16_b=imresize(I16_b,16,'bilinear');
subplot(241),subimage(I128),axis off,title('I128'),
subplot(242),subimage(I64),axis off,title('I64'),
subplot(243),subimage(I32),axis off,title('I32'),
subplot(244),subimage(I16),axis off,title('I16'),
subplot(245),subimage(I128_b),axis off,title('I128_b'),
subplot(246),subimage(I64_b),axis off,title('I64_b'),
subplot(247),subimage(I32_b),axis off,title('I32_b'),
subplot(248),subimage(I16_b),axis off,title('I16_b'),


%{
-------------------------------------------------------------
COMMENT � Part 2: Reducing Spatial Resolution of an Image
-------------------------------------------------------------

Trong ph?n n�y, ?nh g?c 256�256 ???c gi?m ?? ph�n gi?i kh�ng gian xu?ng
128, 64, 32 v� 16 (b?ng h? s? 2), sau ?� ???c ph�ng l?i v? 256�256 ?? 
quan s�t ?nh h??ng c?a kh�ng gian m?u (spatial sampling) v� ph??ng ph�p 
n?i suy (interpolation).

1. Khi gi?m k�ch th??c b?ng nearest neighbor:
-------------------------------------------------
- ?nh b? gi?m chi ti?t r?t r� khi k�ch th??c nh? h?n 64�64.
- C�c kh?i ?i?m (pixel blocks) tr? n�n l?n v� d? th?y.
- Khi ph�ng l?i ?nh nh? (I16, I32�) v? 256�256, 
  hi?n t??ng �blockiness� v� �checkerboard effect� xu?t hi?n r� r?t.
- Bi�n ?nh tr? n�n r?ng c?a, chi ti?t m?m ho?c b? m?t ho�n to�n.
? Nearest neighbor gi? gi� tr? g?c nh?ng t?o ?nh th�, nhi?u kh?i vu�ng.

2. Khi gi?m k�ch th??c b?ng bilinear interpolation:
-----------------------------------------------------
- ?nh sau ph�ng l?i m?n h?n, c�c kh?i pixel vu�ng ???c l�m m?.
- Kh�ng c�n?? checkerboard nh? nearest neighbor.
- Tuy nhi�n, ?nh b? m?t ?? s?c n�t (blurred), ??c bi?t ? bi�n c?a hoa.
- Nh�n t?ng th? t? nhi�n h?n nh?ng �t chi ti?t h?n so v?i nearest neighbor.

3. So s�nh hai ph??ng ph�p:
-----------------------------------------------------
Nearest neighbor:
- Xu?t hi?n kh?i pixel l?n.
- Checkerboard effect r�.
- ?nh s?c n�t h?n nh?ng th� v� m?t t? nhi�n.

Bilinear interpolation:
- ?nh m?n, t? nhi�n h?n.
- Gi?m blockiness.
- B? m? nhi?u khi k�ch th??c qu� nh? (nh? I16_b).

4. Nh?n x�t t?ng quan:
-----------------------------------------------------
- Gi?m spatial resolution l�m m?t c�c chi ti?t t?n s? cao c?a ?nh.
- Khi ph�ng l?i, c�c ph??ng ph�p n?i suy c? �?i?n� th�ng tin v�o 
  nh?ng k?t qu? kh�ng th? kh�i ph?c chi ti?t th?t.
- Nearest neighbor ? kh?i vu�ng v� checkerboard.
- Bilinear ? m??t nh?ng m?.
- ?nh d??i 32�32 coi nh? ?� m?t h?u h?t chi ti?t quan tr?ng.

-------------------------------------------------------------
%}
