% Reading the image and converting it to a gray-level image.
I = imread('dataImages/Fig2_19_a.jpg');



% A 256 gray-level image:
[I256, map256] = gray2ind(I, 256);
% A 128 gray-level image:
[I128, map128] = gray2ind(I, 128);
% A 64 gray-level image:
[I64, map64] = gray2ind(I, 64);

figure(1)
subplot(221), subimage(I), title('I')
subplot(222), subimage(I256, map256), title('I256')
subplot(223), subimage(I128, map128), title('I128')
subplot(224), subimage(I64, map64), title('I64')
pause

% A 32 gray-level image:
[I32, map32] = gray2ind(I, 32);
% A 16 gray-level image:
[I16, map16] = gray2ind(I, 16);
% A 8 gray-level image:
[I8, map8] = gray2ind(I, 8);

figure(2)
subplot(221), subimage(I), title('I')
subplot(222), subimage(I32, map32), title('I32')
subplot(223), subimage(I16, map16), title('I16')
subplot(224), subimage(I8, map8), title('I8')
pause

% A 4 gray-level image:
[I4, map4] = gray2ind(I, 4);
% A 2 gray-level image:
[I2, map2] = gray2ind(I, 2);

figure(3)
subplot(221), subimage(I), title('I')
subplot(222), subimage(I8, map8), title('I8')
subplot(223), subimage(I4, map4), title('I4')
subplot(224), subimage(I2, map2), title('I2')
pause


%{
----------------------------------------
COMMENT � Part 1: Reducing Gray Levels
----------------------------------------

Khi gi?m s? m?c x�m c?a ?nh t? 256 xu?ng 2 m?c, ch?t l??ng ?nh thay ??i 
r� r?t. C�c k?t qu? quan s�t ???c nh? sau:

1. ?nh 256, 128 v� 64 m?c x�m:
- H?u nh? kh�ng c� s? kh�c bi?t ?�ng k? v? m?t th? gi�c.
- C�c v�ng chuy?n ti?p s�ng�t?i v?n m??t v� t? nhi�n.
- Kh�ng xu?t hi?n ???ng vi?n ?o (false contouring).
? M?t ng??i kh� ph�n bi?t s? gi?m m?c x�m khi s? m?c ? 64.

2. ?nh 32 v� 16 m?c x�m:
- B?t ??u th?y r� hi?n t??ng �false contouring�.
- Xu?t hi?n c�c d?i bi�n s�ng�t?i thay v� chuy?n ti?p m??t.
- M?t s? chi ti?t nh? trong c�nh hoa v� n?n b? m?t.
? ?�y l� ng??ng m� ch?t l??ng ?nh b?t ??u gi?m r�.

3. ?nh 8 m?c x�m:
- Hi?n t??ng �posterization� xu?t hi?n m?nh.
- ?nh ch? c�n m?t s? m?ng s�ng t?i l?n.
- C�c chi ti?t m?n g?n nh? bi?n m?t.
? Chuy?n m?c x�m tr? n�n th�, kh�ng t? nhi�n.

4. ?nh 4 v� 2 m?c x�m:
- Ch?t l??ng ?nh gi?m r?t m?nh.
- ?nh 4 m?c: m?t nhi?u chi ti?t, nhi?u v�ng ph?ng l?n.
- ?nh 2 m?c: g?n nh? ?nh nh? ph�n, ch? c�n ?en v� tr?ng.
- C�c bi�n b? r?ng c?a, nhi?u, m?t k?t c?u.
? Kh�ng c�n gi? ???c th�ng tin chi ti?t c?a ?nh g?c.

K?t lu?n:
- T? 64 m?c x�m tr? l�n, ?nh g?n nh? gi? nguy�n ch?t l??ng.
- T? 32 m?c tr? xu?ng, ch?t l??ng gi?m do false contouring.
- ?nh 4 v� 2 m?c x�m kh�ng c�n ph� h?p ?? th? hi?n h�nh ?nh t? nhi�n.

----------------------------------------
%}

