I = imread('dataImages/Fig0308(a)(fractured_spine).tif');
I = im2double(I);

c = 1;   % h? s? log

logI = c * log(1 + I);

figure;
subplot(1,2,1); imshow(I); title('Original Image');
subplot(1,2,2); imshow(logI); title('Log Transformation');