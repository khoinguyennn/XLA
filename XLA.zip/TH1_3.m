%1.3. ??c ?nh �cameraman.tif� v� d�ng h�m imwrite ?? ghi l?i m?t ?nh c� ??nh dang JPEG (ch?ng h?n: Ijpg.jpg) v� m?t ?nh c� ??nh d?ng PNG (ch?ng h?n: Ipng.png). Sau ?� ??c hai ?nh Ijpg.jpg v� Ipng.png v�o hai bi?n t??ng ?ng Ijpg v� Ipng.
%??c l?i ?nh g?c
I = imread('dataImages/cameraman.tif');

%Ghi ?nh th�nh ??nh d?ng JPEG v� PNG
imwrite(I, 'Ijpg.jpg','jpg');
imwrite(I, 'Ipng.png', 'png');

%??c l?i ?nh JPEG v� PNG
Ijpg = imread('Ijpg.jpg');
Ipng = imread('Ipng.png');

%T�nh s? kh�c bi?t tuy?t ??i gi?a hai ?nh

X = imabsdiff(Ijpg, Ipng);

%Hi?n th? s? kh�c bi?t
imagesc(X);
colormap gray;
title('S? kh�c bi?t gi?a ?nh JPEG v� PNG');