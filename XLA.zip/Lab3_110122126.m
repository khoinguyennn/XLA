% 3.1 Ph�t hi?n bi�n Canny
A=imread('dataImages/trui.png');
subplot(3,3,1), imshow(A,[]);
h1=fspecial('gaussian',[15 15],6);
h2=fspecial('gaussian',[30 30],12);
subplot(3,3,4), imshow(imfilter(A,h1),[]);
subplot(3,3,7), imshow(imfilter(A,h2),[]);
[bw,thresh]=edge(A,'log');
subplot(3,3,2), imshow(bw,[]);
[bw,thresh]=edge(A,'canny');
subplot(3,3,3), imshow(bw,[]);
[bw,thresh]=edge(imfilter(A,h1),'log');
subplot(3,3,5), imshow(bw,[]);
[bw,thresh]=edge(imfilter(A,h1),'canny');
subplot(3,3,6), imshow(bw,[]);
[bw,thresh]=edge(imfilter(A,h2),'log');
subplot(3,3,8), imshow(bw,[]);
[bw,thresh]=edge(imfilter(A,h2),'canny');
subplot(3,3,9), imshow(bw,[]);

% 3.2 Ph�t hi?n bi�n
% B??c 1: X�y d?ng c�c m?t n? ph�t hi?n bi�n
w_ngang = [-1 -1 -1; 2 2 2; -1 -1 -1];  % M?t n? ph�t hi?n bi�n ngang
w_45 = [-1 -1 2; -1 2 2; -1 -1 2];      % M?t n? ph�t hi?n bi�n 45�
w_doc = [2 -1 -1; 2 2 -1; -1 -1 -1];    % M?t n? ph�t hi?n bi�n d?c

% B??c 2: ??c ?nh
f = imread('dataImages/Fig1005(a)(wirebond_mask).tif');  % ??c ?nh

% B??c 3: �p d?ng c�c m?t n? ph�t hi?n bi�n l�n ?nh
g_ngang = imfilter(f, w_ngang, 'conv', 'symmetric');  % L?c v?i m?t n? ngang
g_45 = imfilter(f, w_45, 'conv', 'symmetric');       % L?c v?i m?t n? 45�
g_doc = imfilter(f, w_doc, 'conv', 'symmetric');     % L?c v?i m?t n? d?c

% B??c 4: Hi?n th? ?nh g?c v� ?nh sau khi l?c
figure;
subplot(2, 2, 1);
imshow(f);
title('?nh g?c');

subplot(2, 2, 2);
imshow(g_ngang);
title('?nh sau khi ph�t hi?n bi�n ngang');

subplot(2, 2, 3);
imshow(g_45);
title('?nh sau khi ph�t hi?n bi�n 45�');

subplot(2, 2, 4);
imshow(g_doc);
title('?nh sau khi ph�t hi?n bi�n d?c');

% 3.3 Ph�t hi?n bi�n b?ng ph??ng ph�p �sobel�, �prewitt�, �roberts�
% B??c 1: ??c ?nh
f = imread('dataImages/Fig1016(a)(building_original).tif');  % ??c ?nh g?c

% B??c 2: Ph�t hi?n bi�n v?i ph??ng ph�p Sobel
[g_sobel, t_sobel] = edge(f, 'sobel');  % Ph�t hi?n bi�n Sobel (t? ??ng s? d?ng c? 2 h??ng)
% Ho?c ?? ph�t hi?n bi�n theo h??ng d?c:
% [g_sobel, t_sobel] = edge(f, 'sobel', 'vertical'); 

% B??c 3: Ph�t hi?n bi�n v?i ph??ng ph�p Prewitt
[g_prewitt, t_prewitt] = edge(f, 'prewitt');  % Ph�t hi?n bi�n Prewitt

% B??c 4: Ph�t hi?n bi�n v?i ph??ng ph�p Roberts
[g_roberts, t_roberts] = edge(f, 'roberts');  % Ph�t hi?n bi�n Roberts

% B??c 5: Hi?n th? k?t qu?

% Hi?n th? ?nh g?c
figure;
subplot(2, 2, 1);
imshow(f);
title('?nh g?c');

% Hi?n th? ?nh sau khi ph�t hi?n bi�n Sobel
subplot(2, 2, 2);
imshow(g_sobel);
title('Bi�n Sobel');

% Hi?n th? ?nh sau khi ph�t hi?n bi�n Prewitt
subplot(2, 2, 3);
imshow(g_prewitt);
title('Bi�n Prewitt');

% Hi?n th? ?nh sau khi ph�t hi?n bi�n Roberts
subplot(2, 2, 4);
imshow(g_roberts);
title('Bi�n Roberts');


