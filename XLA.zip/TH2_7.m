%2.7. S? d?ng k? thu?t ch?n ng??ng ? ?o?n code 5* v� v� d? ? c�u 2.6. x�c ??nh v� �p ng??ng ??i v?i ?nh pillsetc.png. T??ng t? cho nh?ng ?nh �tape.png�, �coins.png� v� �eight.tif�.

% B??c 1: ??c ?nh
pillsetc = imread('dataImages/pillsetc.png');
tape = imread('dataImages/tape.png');
coins = imread('dataImages/coins.png');
eight = imread('dataImages/eight.tif');

% B??c 2: X�c ??nh ng??ng cho m?i ?nh (s? d?ng gi� tr? trung b�nh)
threshold_pillsetc = mean(pillsetc(:));  % Gi� tr? trung b�nh c?a ?nh pillsetc
threshold_tape = mean(tape(:));  % Gi� tr? trung b�nh c?a ?nh tape
threshold_coins = mean(coins(:));  % Gi� tr? trung b�nh c?a ?nh coins
threshold_eight = mean(eight(:));  % Gi� tr? trung b�nh c?a ?nh eight

% B??c 3: T?o ?nh nh? ph�n b?ng c�ch �p d?ng ng??ng
binary_pillsetc = pillsetc >= threshold_pillsetc;
binary_tape = tape >= threshold_tape;
binary_coins = coins >= threshold_coins;
binary_eight = eight >= threshold_eight;

% B??c 4: Hi?n th? ?nh nh? ph�n
figure;
subplot(2,2,1);
imshow(binary_pillsetc);
title('Anh nhi phan - pillsetc.png');

subplot(2,2,2);
imshow(binary_tape);
title('Anh nhi phan - tape.png');

subplot(2,2,3);
imshow(binary_coins);
title('Anh nhi phan - coins.png');

subplot(2,2,4);
imshow(binary_eight);
title('Anh nhi phan - eight.tif');