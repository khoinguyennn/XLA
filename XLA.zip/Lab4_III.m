I = imread('dataImages/Fig0309(a)(washed_out_aerial_image).tif');
I = im2double(I);

c = 1;

gammas = [0.6 0.4 0.3 3.0 1.0 5.0];

figure;
subplot(2,4,1); imshow(I); title('Original');

for k = 1:length(gammas)
    g = gammas(k);
    output = c * (I.^g);
    subplot(2,4,k+1);
    imshow(output);
    title(['Gamma = ' num2str(g)]);
end