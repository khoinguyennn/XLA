% 3.3 Ph�t hi?n bi�n b?ng ph??ng ph�p �sobel�, �prewitt�, �roberts�
% B??c 1: ??c ?nh
f = imread('dataImages/Fig1016(a)(building_original).tif');  % ??c ?nh g?c

% B??c 2: Ph�t hi?n bi�n v?i ph??ng ph�p Sobel
[g_sobel, t_sobel] = edge(f, 'sobel');  % Ph�t hi?n bi�n Sobel (t? ??ng s? d?ng c? 2 h??ng)
% Ho?c ?? ph�t hi?n bi�n theo h??ng d?c:
% [g_sobel, t_sobel] = edge(f, 'sobel', 'vertical'); 

% B??c 3: Ph�t hi?n bi�n v?i ph??ng ph�p Prewitt
[g_prewitt, t_prewitt] = edge(f, 'prewitt');  % Ph�t hi?n bi�n Prewitt

% B??c 4: Ph�t hi?n bi�n v?i ph??ng ph�p Roberts
[g_roberts, t_roberts] = edge(f, 'roberts');  % Ph�t hi?n bi�n Roberts

% B??c 5: Hi?n th? k?t qu?

% Hi?n th? ?nh g?c
figure;
subplot(2, 2, 1);
imshow(f);
title('Anh goc');

% Hi?n th? ?nh sau khi ph�t hi?n bi�n Sobel
subplot(2, 2, 2);
imshow(g_sobel);
title('Bien Sobel');

% Hi?n th? ?nh sau khi ph�t hi?n bi�n Prewitt
subplot(2, 2, 3);
imshow(g_prewitt);
title('Bien Prewitt');

% Hi?n th? ?nh sau khi ph�t hi?n bi�n Roberts
subplot(2, 2, 4);
imshow(g_roberts);
title('Bien Roberts');
